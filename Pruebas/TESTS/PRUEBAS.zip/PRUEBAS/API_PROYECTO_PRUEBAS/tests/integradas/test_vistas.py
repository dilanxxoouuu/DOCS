import pytest
from flask import json
from flask_jwt_extended import create_access_token
from flaskr.modelos import Usuario, Rol, db

class TestVistaUsuarios:
    """Pruebas integradas para la VistaUsuarios"""

    @pytest.fixture(autouse=True)
    def setup_method(self, client):
        """Configuración inicial para cada test"""
        self.client = client
        # Crear roles necesarios solo si no existen
        with self.client.application.app_context():
            # Limpiar tablas primero para evitar conflictos
            db.session.query(Usuario).delete()
            db.session.query(Rol).delete()
            
            # Crear roles
            admin = Rol(nombre_rol="Administrador")
            cliente = Rol(nombre_rol="Cliente")
            db.session.add_all([admin, cliente])
            db.session.commit()

    def test_crear_usuario_valido(self):
        """Debe crear un usuario con datos válidos"""
        datos_usuario = {
            "nombre": "Ana López",
            "numerodoc": "1234567890",
            "correo": "ana@example.com",
            "contrasena": "Password123"
        }

        response = self.client.post('/usuarios', 
                                 data=json.dumps(datos_usuario),
                                 content_type='application/json')
        
        assert response.status_code == 201
        assert response.json["message"] == "Usuario creado exitosamente"

    def test_crear_usuario_campos_faltantes(self):
        """Debe fallar si faltan campos obligatorios"""
        datos_incompletos = {
            "nombre": "Usuario Incompleto",
            "correo": "incompleto@example.com"
            # Falta numerodoc y contrasena
        }

        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_incompletos),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "Faltan campos obligatorios" in response.json["message"]

    def test_crear_usuario_correo_duplicado(self):
        """Debe fallar si el correo ya está registrado"""
        datos_usuario1 = {
            "nombre": "Usuario correo",
            "numerodoc": "111111111",
            "correo": "duplicado@example.com",
            "contrasena": "12345678"
        }

        # Primer usuario (éxito)
        self.client.post('/usuarios',
                        data=json.dumps(datos_usuario1),
                        content_type='application/json')

        datos_usuario2 = {
            "nombre": "Usuario correo",
            "numerodoc": "222222222",
            "correo": "duplicado@example.com",  # Mismo correo
            "contrasena": "123456789"
        }

        # Segundo usuario con mismo correo (debe fallar)
        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_usuario2),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "El correo ya está registrado" in response.json["message"]

    def test_crear_usuario_documento_duplicado(self):
        """Debe fallar si el número de documento ya está registrado"""
        datos_usuario1 = {
            "nombre": "Usuario documento",
            "numerodoc": "333333333",
            "correo": "doc1@example.com",
            "contrasena": "98765432111"
        }

        # Primer usuario (éxito)
        self.client.post('/usuarios',
                        data=json.dumps(datos_usuario1),
                        content_type='application/json')

        datos_usuario2 = {
            "nombre": "Usuario documento",
            "numerodoc": "333333333",  # Mismo documento
            "correo": "doc2@example.com",
            "contrasena": "987654321"
        }

        # Segundo usuario con mismo documento (debe fallar)
        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_usuario2),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "El número de documento ya está registrado" in response.json["message"]

    def test_validacion_formato_nombre(self):
        """Debe fallar si el nombre contiene caracteres inválidos"""
        datos_invalidos = {
            "nombre": "Usuario 123",  # Números no permitidos
            "numerodoc": "444444444",
            "correo": "nombre@invalido.com",
            "contrasena": "pass123"
        }

        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_invalidos),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "El nombre solo debe contener letras y espacios" in response.json["message"]

    def test_validacion_formato_documento(self):
        """Debe fallar si el documento no es numérico o es muy largo"""
        datos_invalidos = {
            "nombre": "Usuario Válido",
            "numerodoc": "123ABC456",  # Caracteres no numéricos
            "correo": "doc@invalido.com",
            "contrasena": "pass123"
        }

        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_invalidos),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "El número de documento debe contener solo números" in response.json["message"]

    def test_validacion_formato_correo(self):
        """Debe fallar si el correo no tiene formato válido"""
        datos_invalidos = {
            "nombre": "Usuario Válido",
            "numerodoc": "555555555",
            "correo": "correo-invalido",  # Falta @ y dominio
            "contrasena": "pass123"
        }

        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_invalidos),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "Formato de correo electrónico inválido" in response.json["message"]

    def test_validacion_contrasena(self):
        """Debe fallar si la contraseña no cumple con los requisitos"""
        datos_invalidos = {
            "nombre": "Usuario Válido",
            "numerodoc": "666666666",
            "correo": "contrasena@invalida.com",
            "contrasena": "123" 
        }

        response = self.client.post('/usuarios',
                                  data=json.dumps(datos_invalidos),
                                  content_type='application/json')

        assert response.status_code == 400
        assert "La contraseña debe tener entre 8 y 16 caracteres alfanuméricos" in response.json["message"]


class TestVistaUsuario:
    """Pruebas integradas para VistaUsuario (actualización de usuario)"""

    @pytest.fixture(autouse=True)
    def setup_method(self, client):
        """Configuración inicial para cada test"""
        self.client = client
        
        with self.client.application.app_context():
            # Limpieza segura
            db.session.rollback()
            db.session.query(Usuario).delete()
            db.session.query(Rol).delete()
            db.session.commit()

            # Crear roles
            self.rol_admin = Rol(nombre_rol="Administrador")
            self.rol_cliente = Rol(nombre_rol="Cliente")
            db.session.add_all([self.rol_admin, self.rol_cliente])
            db.session.commit()
            db.session.refresh(self.rol_admin)
            db.session.refresh(self.rol_cliente)

            # Crear usuario de prueba
            self.usuario_prueba = Usuario(
                nombre="Usuario Original",
                numerodoc=123456789,
                correo="original@example.com",
                contrasena="123456789",
                rol_id=self.rol_cliente.rol_id
            )
            db.session.add(self.usuario_prueba)
            db.session.commit()
            db.session.refresh(self.usuario_prueba)

            # Generar token JWT
            self.token = create_access_token(identity=str(self.usuario_prueba.id_usuario))

    def test_actualizar_usuario_valido(self):
        """Debe actualizar correctamente un usuario existente"""
        datos_actualizacion = {
            "nombre": "Usuario Modificado",
            "numerodoc": 987654321,
            "correo": "modificado@example.com",
            "rol_id": self.rol_cliente.rol_id
        }

        response = self.client.put(
            f'/usuario/{self.usuario_prueba.id_usuario}',
            data=json.dumps(datos_actualizacion),
            content_type='application/json',
            headers={'Authorization': f'Bearer {self.token}'}
        )

        assert response.status_code == 200
        assert response.json["mensaje"] == "Usuario actualizado correctamente"

        # Verificar cambios en la base de datos - dentro de un contexto de aplicación
        with self.client.application.app_context():
            usuario = Usuario.query.get(self.usuario_prueba.id_usuario)
            rol = Rol.query.get(self.rol_cliente.rol_id)
            
            assert usuario.nombre == "Usuario Modificado"
            assert usuario.numerodoc == 987654321
            assert usuario.correo == "modificado@example.com"
            assert usuario.rol_id == rol.rol_id